fnGO
====


.. automodule:: CoRe.fnGO
    :members:
    :undoc-members:
