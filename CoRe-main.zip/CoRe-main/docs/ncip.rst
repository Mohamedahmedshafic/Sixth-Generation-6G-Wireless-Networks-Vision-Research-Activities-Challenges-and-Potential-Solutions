ncip
====
Network constructor and information propagator (ncip) contains functions for constructing the communication network for the Reactome TopLevelPathways.

.. autoclass:: CoRe.ncip.ncip
    :members:
    :undoc-members:
