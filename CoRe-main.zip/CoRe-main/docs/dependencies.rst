Dependencies
============

- numpy
- scipy
- pandas
- neo4j
- NetworkX
- matplotlib
